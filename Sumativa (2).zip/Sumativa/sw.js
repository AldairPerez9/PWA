// se declara el nombre del cache y los assets para almacenar los archivos al mismo
const devpwa = "pwa-site"
const assets = [
  "/",
  "/index.html",
  "/css/style.css",
  "/js/app.js",
  "/img/icono.png",
  "/img/audifono.png" ]


self.addEventListener("install", installEvent => {
  installEvent.waitUntil(
    caches.open(devpwa).then(cache => {
      cache.addAll(assets)
    })
  )
});

//recuperar los datos
self.addEventListener("fetch", fetchEvent => {
    fetchEvent.respondWith(
      caches.match(fetchEvent.request).then(res => {
        return res || fetch(fetchEvent.request)
      })
    )
  });